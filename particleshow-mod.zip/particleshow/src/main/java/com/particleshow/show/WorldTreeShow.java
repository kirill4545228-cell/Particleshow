package com.particleshow.show;

import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Древо мира: на земле вспыхивает магический круг, из него прорастают светящиеся корни, скрученный ствол и фрактальные ветви
 * (5 уровней, ~90 сегментов), на концах распускаются розово-золотые лепестки, падают лепестки, летают светлячки;
 * финал - золотая вспышка и вихрь лепестков.
 */
public final class WorldTreeShow implements Show {
    private static final int END = 1060;
    private static final int[] DUR = {140, 90, 70, 55, 45};

    private static final class Seg {
        final Vec3d a, b, bend;
        final double w0, w1, len;
        final int t0, dur, depth;
        Seg(Vec3d a, Vec3d b, Vec3d bend, double w0, double w1, double len, int t0, int dur, int depth) {
            this.a = a; this.b = b; this.bend = bend; this.w0 = w0; this.w1 = w1; this.len = len;
            this.t0 = t0; this.dur = dur; this.depth = depth;
        }
        Vec3d at(double s) { return Fx.lerp(a, b, s).add(bend.multiply(Math.sin(Math.PI * s))); }
    }

    private final List<Seg> segs = new ArrayList<>();
    private final List<Seg> roots = new ArrayList<>();
    private final List<Vec3d> tips = new ArrayList<>();
    private final List<Integer> tipT = new ArrayList<>();

    public WorldTreeShow() {
        Random r = new Random(11);
        grow(new Vec3d(0, 0, 0), new Vec3d(0, 1, 0), 30, 5.5, 0, 0, r);
        for (int k = 0; k < 7; k++) {
            double a = k * Fx.TAU / 7 + r.nextDouble() * 0.4;
            Vec3d p = new Vec3d(0, 0.6, 0);
            for (int i = 0; i < 5; i++) {
                a += r.nextGaussian() * 0.3;
                Vec3d e = p.add(Math.cos(a) * 7, 0, Math.sin(a) * 7);
                roots.add(new Seg(p, e, new Vec3d(0, 0, 0), 1.8 * (1 - i * 0.18), 1.8 * (1 - (i + 1) * 0.18), 7, 30 + k * 6 + i * 14, 18, 9));
                p = e;
            }
        }
    }

    private void grow(Vec3d p, Vec3d dir, double len, double w, int depth, int t0, Random r) {
        Vec3d end = p.add(dir.multiply(len));
        Vec3d pp = Fx.perp(dir), qq = dir.crossProduct(pp);
        double ba = r.nextDouble() * Fx.TAU;
        Vec3d bend = pp.multiply(Math.cos(ba)).add(qq.multiply(Math.sin(ba))).multiply(len * 0.14);
        segs.add(new Seg(p, end, bend, w, w * 0.62, len, t0, DUR[depth], depth));
        if (depth == 4) {
            tips.add(end);
            tipT.add(t0 + DUR[depth]);
            return;
        }
        int kids = depth == 0 ? 4 : (depth < 3 ? 3 : 2);
        double az0 = r.nextDouble() * Fx.TAU;
        for (int k = 0; k < kids; k++) {
            double az = az0 + k * Fx.TAU / kids + r.nextGaussian() * 0.2;
            double spread = 0.55 + 0.25 * r.nextDouble();
            Vec3d cd = Fx.rot(Fx.rot(dir, pp, spread), dir, az);
            cd = new Vec3d(cd.x, cd.y + 0.35, cd.z).normalize();
            grow(end, cd, len * 0.74, w * 0.62, depth + 1, t0 + DUR[depth] - 15, r);
        }
    }

    @Override public String id() { return "worldtree"; }
    @Override public String title() { return "Древо мира: магический круг, корни, ветви, лепестки и светлячки (очень много частиц)"; }
    @Override public int duration() { return 1100; }
    @Override public double distance() { return 100; }

    private static final int[] BARK = {0xB86A2A, 0xD68A3A, 0xE8A64A, 0xF4C26A, 0xFFE29A};

    private void draw(ShowContext c, Seg g, double s, int t) {
        Vec3d P = g.at(s), T = g.at(Math.min(1, s + 0.01)).subtract(P);
        if (T.lengthSquared() < 1e-9) return;
        T = T.normalize();
        Vec3d n1 = Fx.perp(T), n2 = T.crossProduct(n1);
        double w = Fx.lerp(g.w0, g.w1, s);
        int k = (int) Fx.clamp((int) (w * 1.3 + 1.5), 2, 7);
        if (g.depth == 9) k = 2;
        double twist = s * g.len * 0.35 + g.depth;
        int col = g.depth == 9 ? Fx.mix(0x4FE0C8, 0xFFC060, s) : BARK[g.depth];
        for (int j = 0; j < k; j++) {
            double ang = twist + j * Fx.TAU / k;
            Vec3d o = n1.multiply(Math.cos(ang) * w).add(n2.multiply(Math.sin(ang) * w));
            c.emit(new Spec(Kind.GLOW).pos(c.at(P.x + o.x, P.y + o.y, P.z + o.z)).life(Math.max(2, END - t)).size(0.55)
                    .color(col).alpha(0.8).fade(4, 60).rise(0.003));
        }
    }

    @Override
    public void tick(ShowContext c, int t) {
        Random r = c.rng();
        if (t == 0) c.sound("minecraft:block.beacon.activate", 1f, 0.6f);
        if (t == 140) c.sound("minecraft:block.amethyst_block.chime", 1f, 0.6f);
        if (t == 350) c.sound("minecraft:entity.firework_rocket.twinkle_far", 1f, 0.8f);
        if (t == 1000) c.sound("minecraft:entity.warden.sonic_boom", 0.8f, 1.2f);

        // магический круг
        if (t < 120) {
            double p0 = Fx.ramp(t - 1, 0, 120), p1 = Fx.ramp(t, 0, 120);
            double ds = 0.45 / (Fx.TAU * 40);
            for (int q = (int) Math.floor(p0 / ds) + 1; q <= (int) Math.floor(p1 / ds); q++) {
                double a = q * ds * Fx.TAU;
                c.emit(new Spec(Kind.GLOW).pos(c.at(Math.cos(a) * 40, 0.5, Math.sin(a) * 40)).life(END - t).size(0.5).color(0x8AF0FF).alpha(0.85).fade(4, 60));
            }
            for (int q = (int) Math.floor(p0 * 24) + 1; q <= (int) Math.floor(p1 * 24); q++) {
                double a = q * Fx.TAU / 24;
                for (int m = 0; m < 5; m++)
                    c.emit(new Spec(Kind.GLOW).pos(c.at(Math.cos(a) * (36 + m), 0.5, Math.sin(a) * (36 + m))).life(END - t).size(0.4).color(0xFFE29A).alpha(0.8).fade(4, 60));
            }
        }
        if (t >= 60 && t < 120) {
            double p0 = Fx.ramp(t - 1, 60, 120), p1 = Fx.ramp(t, 60, 120);
            double ds = 0.7 / 62;
            for (int q = (int) Math.floor(p0 / ds) + 1; q <= (int) Math.floor(p1 / ds); q++) {
                double s = q * ds;
                for (int i = 0; i < 6; i++) {
                    double a1 = i * Fx.TAU / 6, a2 = ((i + 2) % 6) * Fx.TAU / 6;
                    double x = Fx.lerp(Math.cos(a1), Math.cos(a2), s) * 36, z = Fx.lerp(Math.sin(a1), Math.sin(a2), s) * 36;
                    c.emit(new Spec(Kind.GLOW).pos(c.at(x, 0.5, z)).life(END - t).size(0.4).color(0xB8A0FF).alpha(0.75).fade(4, 60));
                }
            }
        }
        if (t % 70 == 10 && t < 700)
            c.emit(new Spec(Kind.RING).pos(c.at(0, 0.8, 0)).life(50).size(2).grow(0.9).color(0x8AF0FF).alpha(0.6).fade(3, 35));

        // корни и ветви
        for (Seg g : roots) segment(c, g, t);
        for (Seg g : segs) segment(c, g, t);

        // листва
        for (int i = 0; i < tips.size(); i++) {
            int tb = tipT.get(i);
            Vec3d tp = tips.get(i);
            if (t == tb)
                for (int k = 0; k < 5; k++)
                    c.emit(new Spec(Kind.GLOW).pos(c.at(tp.x + r.nextGaussian() * 2, tp.y + r.nextGaussian(), tp.z + r.nextGaussian() * 2))
                            .life(END - t).size(5).color(0xFF9AD0).alpha(0.12).fade(20, 60));
            if (t >= tb && t < tb + 32) {
                double q = r.nextDouble();
                int col = q < 0.55 ? 0xFF8FC8 : (q < 0.8 ? 0xFFD6EC : 0x7FF0FF);
                Spec sp = new Spec(Kind.GLOW).pos(c.at(tp.x + r.nextGaussian() * 3.5, tp.y + r.nextGaussian() * 1.6, tp.z + r.nextGaussian() * 3.5))
                        .life(END - t).size(0.55).color(col).alpha(0.9).fade(6, 60);
                if (r.nextInt(5) == 0) sp.twinkle();
                c.emit(sp);
            }
        }

        // падающие лепестки и светлячки
        if (t >= 430 && t < END - 100 && !tips.isEmpty()) {
            for (int i = 0; i < 12; i++) {
                Vec3d tp = tips.get(r.nextInt(tips.size()));
                double q = r.nextDouble();
                c.emit(new Spec(Kind.GLOW).pos(c.at(tp.x + r.nextGaussian() * 3, tp.y, tp.z + r.nextGaussian() * 3))
                        .vel(0.04 + r.nextGaussian() * 0.02, -0.07, r.nextGaussian() * 0.02).life(140).size(0.38)
                        .color(q < 0.6 ? 0xFFB0D8 : 0xFFFFFF).alpha(0.85).fade(5, 30).twinkle());
            }
        }
        if (t >= 150 && t < END - 60) {
            for (int i = 0; i < 6; i++) {
                double a = r.nextDouble() * Fx.TAU, rad = 8 + r.nextDouble() * 40;
                c.emit(new Spec(Kind.STAR).pos(c.at(Math.cos(a) * rad, r.nextDouble() * 45, Math.sin(a) * rad))
                        .vel(r.nextGaussian() * 0.02, r.nextGaussian() * 0.02, r.nextGaussian() * 0.02)
                        .life(120).size(0.3).color(0xFFF0A0).fade(15, 40).twinkle());
            }
        }

        // финал
        if (t == 1000) {
            Vec3d top = c.at(0, 55, 0);
            c.emit(new Spec(Kind.GLOW).pos(top).life(16).size(24).color(0xFFF0C0).alpha(0.9).fade(1, 14));
            for (int i = 0; i < 400; i++) {
                double a = r.nextDouble() * Fx.TAU, h = r.nextDouble() * 70, rad = 4 + h * 0.3;
                c.emit(new Spec(Kind.GLOW).pos(c.at(Math.cos(a) * rad, h, Math.sin(a) * rad))
                        .vel(-Math.sin(a) * 0.5, 0.35 + r.nextDouble() * 0.4, Math.cos(a) * 0.5)
                        .life(70).size(0.5).color(i % 2 == 0 ? 0xFFD27A : 0xFF9AD0).fade(3, 40).twinkle());
            }
            Fx.shock(c, c.at(0, 0.6, 0), 2.2, 220, 0xFFE29A, 40, 0.7);
        }
    }

    private void segment(ShowContext c, Seg g, int t) {
        double p0 = Fx.ramp(t - 1, g.t0, g.t0 + g.dur), p1 = Fx.ramp(t, g.t0, g.t0 + g.dur);
        if (p1 <= p0) return;
        double ds = (g.depth == 9 ? 0.7 : 0.55) / g.len;
        for (int q = (int) Math.floor(p0 / ds) + 1; q <= (int) Math.floor(p1 / ds); q++) draw(c, g, q * ds, t);
        if (g.depth <= 4) {
            Vec3d h = g.at(p1);
            c.emit(new Spec(Kind.GLOW).pos(c.at(h.x, h.y, h.z)).life(3).size(1.1 + 0.2 * (4 - g.depth)).color(0xFFF0C0).fade(0, 2));
        }
    }
}
