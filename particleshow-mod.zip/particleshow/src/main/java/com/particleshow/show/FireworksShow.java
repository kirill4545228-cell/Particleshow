package com.particleshow.show;

import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Грандиозный салют: 8 видов залпов (сфера, сатурн, сердце, ива, спираль, звезда, гироскоп, пальма) и финальный залп. */
public final class FireworksShow implements Show {
    private static final int FLIGHT = 36;
    private static final int[][] PAL = {
            {0xFF4A4A, 0xFFD24A}, {0x4AB8FF, 0xFFFFFF}, {0x6BFF8A, 0xE7FF4A},
            {0xC04AFF, 0xFF4AC8}, {0xFF9A2A, 0xFFE08A}, {0xFFFFFF, 0xA0C8FF}};

    private static final class Ev {
        final int t, type, c1, c2;
        final double x, z, h;
        Ev(int t, int type, double x, double z, double h, int c1, int c2) {
            this.t = t; this.type = type; this.x = x; this.z = z; this.h = h; this.c1 = c1; this.c2 = c2;
        }
    }

    private final List<Ev> evs = new ArrayList<>();

    public FireworksShow() {
        Random r = new Random(2026);
        int tt = FLIGHT + 6;
        for (int n = 0; n < 16; n++) {
            int[] p = PAL[r.nextInt(PAL.length)];
            evs.add(new Ev(tt, n % 8, (r.nextDouble() - 0.5) * 90, (r.nextDouble() - 0.5) * 40, 60 + r.nextDouble() * 40, p[0], p[1]));
            tt += 38 + r.nextInt(25);
        }
        int f0 = Math.max(tt + 30, 740);
        for (int i = 0; i < 16; i++) {
            int[] p = PAL[r.nextInt(PAL.length)];
            evs.add(new Ev(f0 + i * 5, r.nextInt(8), (r.nextDouble() - 0.5) * 120, (r.nextDouble() - 0.5) * 50, 55 + r.nextDouble() * 55, p[0], p[1]));
        }
    }

    @Override public String id() { return "fireworks"; }
    @Override public String title() { return "Грандиозный салют: сердца, звёзды, ивы, сатурны и финальный залп"; }
    @Override public int duration() { return 1000; }
    @Override public double distance() { return 85; }

    @Override
    public void tick(ShowContext c, int t) {
        Random r = c.rng();
        for (Ev e : evs) {
            int L = e.t - FLIGHT;
            if (t == L) c.sound("minecraft:entity.firework_rocket.launch", 0.7f, 1f);
            if (t >= L && t < e.t) rocket(c, e, t - L, r);
            if (t == e.t) burst(c, e, r);
            if (t == e.t + 8) c.sound("minecraft:entity.firework_rocket.twinkle_far", 0.6f, 1f);
        }
    }

    private void rocket(ShowContext c, Ev e, int k, Random r) {
        double tau = (k + 1) / (double) FLIGHT;
        double y = e.h * (1 - (1 - tau) * (1 - tau));
        Vec3d p = c.at(e.x, y, e.z);
        c.emit(new Spec(Kind.GLOW).pos(p).life(2).size(0.8).color(0xFFE0A0).fade(0, 1));
        for (int i = 0; i < 4; i++)
            c.emit(new Spec(Kind.SPARK).pos(p).vel(r.nextGaussian() * 0.03, -0.08, r.nextGaussian() * 0.03).gravity(0.01)
                    .life(14).size(0.28).color(0xFFB060).alpha(0.8).fade(0, 10));
    }

    private void spark(ShowContext c, Vec3d b, Vec3d v, int col, int life, double grav, double drag) {
        c.emit(new Spec(Kind.GLOW).pos(b).vel(v).drag(drag).gravity(grav).life(life).size(0.55).color(col).alpha(0.9).fade(2, 25));
    }

    private void burst(ShowContext c, Ev e, Random r) {
        Vec3d b = c.at(e.x, e.h, e.z);
        c.emit(new Spec(Kind.GLOW).pos(b).life(6).size(6).color(0xFFFFFF).alpha(0.9).fade(0, 5));
        c.sound("minecraft:entity.firework_rocket.blast_far", 0.9f, 0.9f);
        Vec3d v = c.toViewer();
        Vec3d rt = new Vec3d(-v.z, 0, v.x), up = new Vec3d(0, 1, 0);
        switch (e.type) {
            case 0:
                for (int i = 0; i < 520; i++) spark(c, b, Fx.randDir(r).multiply(1.7 * (0.97 + 0.06 * r.nextDouble())), i % 2 == 0 ? e.c1 : e.c2, 70, 0.012, 0.93);
                break;
            case 1: {
                for (int i = 0; i < 240; i++) spark(c, b, Fx.randDir(r).multiply(1.25), e.c1, 70, 0.012, 0.93);
                Vec3d nrm = new Vec3d(0.3, 1, 0.2).normalize(), b1 = Fx.perp(nrm), b2 = nrm.crossProduct(b1);
                for (int i = 0; i < 300; i++) {
                    double a = i * Fx.TAU / 300;
                    spark(c, b, b1.multiply(Math.cos(a)).add(b2.multiply(Math.sin(a))).multiply(2.0), e.c2, 70, 0.006, 0.93);
                }
                break;
            }
            case 2:
                for (int i = 0; i < 340; i++) {
                    double tt = i * Fx.TAU / 340, s = 0.0787;
                    double hx = 16 * Math.pow(Math.sin(tt), 3);
                    double hy = 13 * Math.cos(tt) - 5 * Math.cos(2 * tt) - 2 * Math.cos(3 * tt) - Math.cos(4 * tt);
                    spark(c, b, rt.multiply(hx * s).add(up.multiply(hy * s)), i % 3 == 0 ? 0xFF9AB0 : 0xFF3A6A, 80, 0.003, 0.93);
                }
                for (int i = 0; i < 120; i++) {
                    double tt = r.nextDouble() * Fx.TAU, s = 0.0787 * (0.2 + 0.6 * r.nextDouble());
                    double hx = 16 * Math.pow(Math.sin(tt), 3);
                    double hy = 13 * Math.cos(tt) - 5 * Math.cos(2 * tt) - 2 * Math.cos(3 * tt) - Math.cos(4 * tt);
                    spark(c, b, rt.multiply(hx * s).add(up.multiply(hy * s)), 0xFF6A8A, 70, 0.003, 0.93);
                }
                break;
            case 3:
                for (int i = 0; i < 420; i++) spark(c, b, Fx.randDir(r).multiply(1.1 + 0.8 * r.nextDouble()), i % 3 == 0 ? 0xFFE9A0 : 0xFFC040, 115, 0.02, 0.945);
                break;
            case 4:
                for (int i = 0; i < 420; i++) {
                    double ph = Math.acos(1 - 2 * (i + 0.5) / 420), th = i * 0.62;
                    Vec3d d = new Vec3d(Math.sin(ph) * Math.cos(th), Math.cos(ph), Math.sin(ph) * Math.sin(th));
                    spark(c, b, d.multiply(1.7), (i / 20) % 2 == 0 ? e.c1 : e.c2, 75, 0.01, 0.93);
                }
                break;
            case 5:
                for (int k = 0; k < 5; k++) {
                    double a1 = Math.PI / 2 + k * 4 * Math.PI / 5, a2 = Math.PI / 2 + (k + 1) * 4 * Math.PI / 5;
                    for (int i = 0; i < 70; i++) {
                        double f = i / 70.0;
                        double x = Fx.lerp(Math.cos(a1), Math.cos(a2), f), y = Fx.lerp(Math.sin(a1), Math.sin(a2), f);
                        spark(c, b, rt.multiply(x * 1.4).add(up.multiply(y * 1.4)), e.c1, 75, 0.004, 0.93);
                    }
                }
                for (int i = 0; i < 80; i++) spark(c, b, Fx.randDir(r).multiply(0.5), e.c2, 60, 0.006, 0.93);
                break;
            case 6:
                for (int m = 0; m < 3; m++) {
                    Vec3d nrm = new Vec3d(m == 0 ? 1 : 0, m == 1 ? 1 : 0, m == 2 ? 1 : 0), b1 = Fx.perp(nrm), b2 = nrm.crossProduct(b1);
                    for (int i = 0; i < 150; i++) {
                        double a = i * Fx.TAU / 150;
                        spark(c, b, b1.multiply(Math.cos(a)).add(b2.multiply(Math.sin(a))).multiply(1.8), m == 1 ? e.c2 : e.c1, 75, 0.006, 0.93);
                    }
                }
                break;
            default:
                for (int a = 0; a < 12; a++) {
                    double ang = a * Fx.TAU / 12;
                    Vec3d d = new Vec3d(Math.cos(ang) * 0.8, 0.6, Math.sin(ang) * 0.8).normalize();
                    for (int i = 0; i < 30; i++) spark(c, b, d.multiply(0.7 + i * 0.045), i > 24 ? 0xFFFFFF : e.c1, 100, 0.035, 0.95);
                }
                break;
        }
    }
}
