package com.particleshow.show;

/** Типы частиц мода (у каждого своя текстура и свой ParticleType). */
public enum Kind { GLOW, SPARK, STAR, RING, EMBER }
