package com.particleshow.show;

import net.minecraft.util.math.Vec3d;
import java.util.Random;

public final class Fx {
    public static final double TAU = Math.PI * 2;
    private Fx() {}

    public static double clamp(double v, double a, double b) { return v < a ? a : Math.min(v, b); }
    public static double ramp(double t, double a, double b) { return clamp((t - a) / (b - a), 0, 1); }
    public static double smooth(double x) { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); }
    public static double lerp(double a, double b, double t) { return a + (b - a) * t; }
    public static Vec3d lerp(Vec3d a, Vec3d b, double t) { return a.add(b.subtract(a).multiply(t)); }
    public static double frac(double x) { return x - Math.floor(x); }

    /** Поворот вектора v вокруг единичной оси axis на угол ang (формула Родрига). */
    public static Vec3d rot(Vec3d v, Vec3d axis, double ang) {
        double c = Math.cos(ang), s = Math.sin(ang);
        return v.multiply(c).add(axis.crossProduct(v).multiply(s)).add(axis.multiply(axis.dotProduct(v) * (1 - c)));
    }

    /** Любой единичный вектор, перпендикулярный a. */
    public static Vec3d perp(Vec3d a) {
        Vec3d h = Math.abs(a.y) < 0.9 ? new Vec3d(0, 1, 0) : new Vec3d(1, 0, 0);
        return a.crossProduct(h).normalize();
    }

    public static Vec3d randDir(Random r) {
        double z = r.nextDouble() * 2 - 1, a = r.nextDouble() * TAU, s = Math.sqrt(1 - z * z);
        return new Vec3d(s * Math.cos(a), z, s * Math.sin(a));
    }

    public static int mix(int a, int b, double t) {
        t = clamp(t, 0, 1);
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    public static int hsv(double h, double s, double v) {
        h = h - Math.floor(h);
        double hh = h * 6;
        int i = (int) hh;
        double f = hh - i, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        double r, g, b;
        switch (i % 6) {
            case 0: r = v; g = t; b = p; break;
            case 1: r = q; g = v; b = p; break;
            case 2: r = p; g = v; b = t; break;
            case 3: r = p; g = q; b = v; break;
            case 4: r = t; g = p; b = v; break;
            default: r = v; g = p; b = q; break;
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    /** Зигзагообразная молния между двумя МИРОВЫМИ точками. jitter - в локальных единицах. */
    public static void bolt(ShowContext c, Vec3d a, Vec3d b, int rgb, double size, int life, double jitter) {
        Random r = c.rng();
        Vec3d d = b.subtract(a);
        double len = d.length();
        if (len < 0.1) return;
        Vec3d dir = d.multiply(1.0 / len);
        Vec3d n1 = perp(dir), n2 = dir.crossProduct(n1);
        int segs = Math.max(4, (int) (len / (4 * c.scale())));
        Vec3d[] pts = new Vec3d[segs + 1];
        for (int i = 0; i <= segs; i++) {
            double f = i / (double) segs;
            double amp = (i == 0 || i == segs) ? 0 : jitter * c.scale();
            Vec3d base = a.add(d.multiply(f));
            pts[i] = base.add(n1.multiply(r.nextGaussian() * amp)).add(n2.multiply(r.nextGaussian() * amp));
        }
        double step = 0.7 * c.scale();
        for (int i = 0; i < segs; i++) {
            Vec3d p = pts[i], q = pts[i + 1];
            int n = Math.max(1, (int) (q.subtract(p).length() / step));
            for (int k = 0; k < n; k++) {
                Vec3d x = lerp(p, q, k / (double) n);
                c.emit(new Spec(Kind.GLOW).pos(x).life(life).size(size).color(rgb).alpha(0.9).fade(0, life / 2 + 1));
                c.emit(new Spec(Kind.GLOW).pos(x).life(Math.max(1, life / 2)).size(size * 0.5).color(0xFFFFFF).fade(0, 2));
            }
        }
    }

    /** Расходящееся по земле кольцо искр. center - МИРОВАЯ точка, speed - локальных блоков за тик. */
    public static void shock(ShowContext c, Vec3d center, double speed, int n, int rgb, int life, double size) {
        Random r = c.rng();
        for (int i = 0; i < n; i++) {
            double a = i * TAU / n + r.nextDouble() * 0.05;
            double sp = speed * (0.9 + 0.2 * r.nextDouble());
            c.emit(new Spec(Kind.SPARK).pos(center).vel(Math.cos(a) * sp, 0.02, Math.sin(a) * sp)
                    .life(life).size(size).color(rgb).drag(0.96).fade(1, life / 2));
        }
    }
}
