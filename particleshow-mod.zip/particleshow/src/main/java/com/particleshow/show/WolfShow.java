package com.particleshow.show;

import net.minecraft.util.math.Vec3d;
import java.util.Random;

/**
 * Небесный волк: серебристо-голубой волк из частиц несётся по небу на фоне полной луны. Настоящий галоп:
 * у каждой лапы два сустава и своя фаза, корпус покачивается, хвост волнами, по телу текут клочья шерсти.
 * За волком остаётся звёздная пыль и переливающаяся лента сияния.
 */
public final class WolfShow implements Show {
    private static final int RUN = 440;
    private static final double K = 1.35;
    private static final int[] FUR = {0x9FD0FF, 0xCFE8FF, 0xFFFFFF, 0x8FB4FF};

    @Override public String id() { return "wolf"; }
    @Override public String title() { return "Небесный волк, бегущий по небу на фоне луны"; }
    @Override public int duration() { return 560; }
    @Override public double distance() { return 100; }

    private static final class Fr {
        Vec3d p, f, u, r;
        double bob, pitch;
    }

    private Vec3d path(double s, Vec3d dir, Vec3d v) {
        double x = -130 + 260 * s;
        double depth = -10 + 40 * Math.sin(Math.PI * s);
        double y = 64 + 34 * Math.sin(Math.PI * Math.pow(s, 0.9)) + 2.5 * Math.sin(s * 40);
        return dir.multiply(x).add(v.multiply(depth)).add(0, y, 0);
    }

    /** Точка модели волка (x вперёд, y вверх, z вбок) -> локальные координаты шоу. */
    private Vec3d m(Fr fr, double x, double y, double z) {
        double cp = Math.cos(fr.pitch), sp = Math.sin(fr.pitch);
        double xx = x * cp - y * sp, yy = x * sp + y * cp + fr.bob;
        return fr.p.add(fr.f.multiply(xx * K)).add(fr.u.multiply(yy * K)).add(fr.r.multiply(z * K));
    }

    private void put(ShowContext c, Fr fr, double x, double y, double z, double size, int col, double alpha, Vec3d vel, int life) {
        Vec3d w = m(fr, x, y, z);
        c.emit(new Spec(Kind.GLOW).pos(c.at(w.x, w.y, w.z)).vel(vel).life(life).size(size).color(col).alpha(alpha).fade(1, Math.max(1, life - 1)));
    }

    @Override
    public void tick(ShowContext c, int t) {
        Random r = c.rng();
        Vec3d v = c.toViewer();
        Vec3d dir = new Vec3d(v.z, 0, -v.x);
        if (t == 0) { c.sound("minecraft:entity.wolf.howl", 1f, 0.8f); }
        if (t == 220) c.sound("minecraft:entity.wolf.howl", 0.8f, 1.0f);
        moon(c, t, v, r);
        if (t > RUN) return;

        double s = t / (double) RUN;
        Fr fr = new Fr();
        fr.p = path(s, dir, v);
        Vec3d pn = path(s + 1.0 / RUN, dir, v);
        Vec3d vel = pn.subtract(fr.p);
        fr.f = vel.normalize();
        fr.r = fr.f.crossProduct(new Vec3d(0, 1, 0)).normalize();
        fr.u = fr.r.crossProduct(fr.f).normalize();
        double phi = t * 0.5;
        fr.bob = 0.9 * Math.sin(2 * phi);
        fr.pitch = 0.1 * Math.sin(2 * phi + 0.8);
        Vec3d back = fr.f.multiply(-0.22);

        // корпус
        for (int i = 0; i < 150; i++) {
            Vec3d d = Fx.randDir(r);
            double bx = d.x * 7.5, by = 1 + d.y * 3.0 * (1 + 0.15 * d.x), bz = d.z * 2.4;
            put(c, fr, bx, by, bz, 0.62, Fx.mix(FUR[r.nextInt(4)], 0xFFFFFF, r.nextDouble() * 0.4), 0.85, vel, 3);
        }
        for (int i = 0; i < 40; i++) {
            Vec3d d = Fx.randDir(r).multiply(Math.sqrt(r.nextDouble()));
            put(c, fr, d.x * 7, 1 + d.y * 2.6, d.z * 2.0, 0.8, 0xB8DCFF, 0.35, vel, 3);
        }
        for (int i = 0; i < 40; i++) {
            Vec3d d = Fx.randDir(r);
            put(c, fr, d.x * 7.5, 1 + d.y * 3.2 + 0.5, d.z * 2.6, 0.5, 0xFFFFFF, 0.45, vel.add(back), 10);
        }
        // шея и голова
        for (int i = 0; i < 20; i++) {
            double q = r.nextDouble(), a = r.nextDouble() * Fx.TAU;
            put(c, fr, 6 + 2.8 * q, 1.5 + 1.6 * q + Math.sin(a) * 1.8, Math.cos(a) * 1.7, 0.65, 0xCFE8FF, 0.8, vel, 3);
        }
        for (int i = 0; i < 40; i++) {
            Vec3d d = Fx.randDir(r);
            put(c, fr, 9.8 + d.x * 2.3, 3.3 + d.y * 2.2, d.z * 2.0, 0.6, 0xE6F2FF, 0.9, vel, 3);
        }
        for (int i = 0; i < 30; i++) {
            double q = r.nextDouble(), a = r.nextDouble() * Fx.TAU, rad = 1.3 - 0.75 * q;
            put(c, fr, 11.8 + 4.2 * q, 2.7 + Math.sin(a) * rad * 0.85, Math.cos(a) * rad, 0.5, 0xFFFFFF, 0.9, vel, 3);
        }
        put(c, fr, 16.2, 2.9, 0, 0.8, 0x6FA8FF, 1.0, vel, 3);
        for (int sd = -1; sd <= 1; sd += 2) {
            for (int i = 0; i < 14; i++) {
                double q = i / 13.0;
                put(c, fr, 8.8 - 0.8 * q, 5.0 + 3.2 * q, sd * (1.4 + 0.2 * q) * (1 - 0.4 * q), 0.5, 0xFFFFFF, 0.9, vel, 3);
            }
            put(c, fr, 11.7, 3.9, sd * 1.05, 0.95, 0xFFE066, 1.0, vel, 3);
            put(c, fr, 11.7, 3.9, sd * 1.05, 2.0, 0xFFC040, 0.4, vel, 3);
        }
        // хвост
        for (int i = 0; i <= 16; i++) {
            double q = i / 16.0;
            double tx = -7.5 - 9 * q, ty = 1.8 + 3.0 * Math.sin(Math.PI * 0.8 * q), tz = Math.sin(t * 0.3 - q * 3.2) * 1.4 * q;
            double rad = 1.5 * (1 - 0.45 * q) + 0.2;
            for (int j = 0; j < 3; j++) {
                double a = r.nextDouble() * Fx.TAU;
                put(c, fr, tx, ty + Math.sin(a) * rad, tz + Math.cos(a) * rad, 0.6, Fx.mix(0xCFE8FF, 0x7FA8FF, q), 0.8, vel.add(back), 4);
            }
        }
        // лапы: два сустава, у каждой своя фаза
        double[][] legs = {{4.5, 1.6, 0.0, 1}, {4.5, -1.6, 0.4, 1}, {-4.5, 1.6, 2.6, -1}, {-4.5, -1.6, 3.0, -1}};
        for (double[] L : legs) {
            double psi = L[2], dirSign = L[3];
            double a = 0.85 * Math.sin(phi + psi);
            double fold = 0.4 + 0.8 * Math.max(0, Math.cos(phi + psi));
            double b = a - dirSign * fold;
            double hx = L[0], hy = 0.2, hz = L[1];
            double kx = hx + Math.sin(a) * 3.8, ky = hy - Math.cos(a) * 3.8;
            double px = kx + Math.sin(b) * 3.8, py = ky - Math.cos(b) * 3.8;
            for (double q = 0; q <= 1.0; q += 0.14) {
                put(c, fr, hx + (kx - hx) * q, hy + (ky - hy) * q, hz, 0.7 - 0.2 * q, 0xDCEEFF, 0.9, vel, 3);
                put(c, fr, kx + (px - kx) * q, ky + (py - ky) * q, hz, 0.55 - 0.15 * q, 0xFFFFFF, 0.9, vel, 3);
            }
            put(c, fr, px, py, hz, 1.1, 0xFFFFFF, 0.9, vel, 3);
            if (py < -4.2 || r.nextInt(4) == 0) {
                Vec3d w = m(fr, px, py, hz);
                c.emit(new Spec(Kind.STAR).pos(c.at(w.x, w.y, w.z)).vel(back.multiply(1.2)).life(24).size(0.9).color(0xBFE0FF).fade(1, 16).twinkle());
            }
        }
        // звёздная пыль и лента сияния
        for (int i = 0; i < 36; i++) {
            Vec3d q = fr.p.subtract(fr.f.multiply(5 + r.nextDouble() * 10)).add(r.nextGaussian() * 2, r.nextGaussian() * 2, r.nextGaussian() * 2);
            c.emit(new Spec(Kind.STAR).pos(c.at(q.x, q.y, q.z)).vel(r.nextGaussian() * 0.03, r.nextGaussian() * 0.03, r.nextGaussian() * 0.03)
                    .life(70).size(0.35).color(Fx.mix(0x7FB8FF, 0xFFFFFF, r.nextDouble())).fade(3, 30).twinkle());
        }
        for (int i = 0; i < 50; i++) {
            Vec3d q = fr.p.subtract(fr.f.multiply(r.nextDouble() * 14)).add(r.nextGaussian() * 3, r.nextGaussian() * 2.5, r.nextGaussian() * 3);
            c.emit(new Spec(Kind.GLOW).pos(c.at(q.x, q.y, q.z)).life(90).size(3.0).color(Fx.mix(0x4A8CFF, 0xB05CFF, r.nextDouble()))
                    .alpha(0.09).fade(10, 50));
        }
        Vec3d e1 = m(fr, 11.7, 3.9, 1.05), e2 = m(fr, 11.7, 3.9, -1.05);
        c.emit(new Spec(Kind.GLOW).pos(c.at(e1.x, e1.y, e1.z)).life(30).size(0.4).color(0xFFD060).alpha(0.8).fade(0, 25));
        c.emit(new Spec(Kind.GLOW).pos(c.at(e2.x, e2.y, e2.z)).life(30).size(0.4).color(0xFFD060).alpha(0.8).fade(0, 25));
    }

    private void moon(ShowContext c, int t, Vec3d v, Random r) {
        if (t > 100) return;
        Vec3d rt = new Vec3d(-v.z, 0, v.x);
        double mx = -v.x * 50, mz = -v.z * 50, my = 98;
        for (int i = 0; i < 18; i++) {
            double rad = 24 * Math.sqrt(r.nextDouble()), a = r.nextDouble() * Fx.TAU;
            double u = Math.cos(a) * rad, w = Math.sin(a) * rad;
            double crater = 0.5 + 0.5 * Math.sin(u * 0.5) * Math.cos(w * 0.45 + 1.0);
            c.emit(new Spec(Kind.GLOW).pos(c.at(mx + rt.x * u, my + w, mz + rt.z * u)).life(Math.max(60, 560 - t)).size(1.5)
                    .color(Fx.mix(0xFFF6D8, 0xE8E2C8, crater)).alpha(0.3 + 0.3 * (1 - crater)).fade(30, 60));
        }
        if (t == 60) c.emit(new Spec(Kind.GLOW).pos(c.at(mx, my, mz)).life(Math.max(60, 500)).size(34).color(0xCFE0FF).alpha(0.08).fade(30, 80));
    }
}
