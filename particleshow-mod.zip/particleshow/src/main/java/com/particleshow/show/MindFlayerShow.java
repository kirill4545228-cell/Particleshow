package com.particleshow.show;

import net.minecraft.util.math.Vec3d;
import java.util.Random;

/**
 * Истязатель разума (большая версия, ~100 блоков в высоту).
 * Точка -> 48 полосок плывут вокруг неё и сплетаются в шар -> шар схлопывается в тело-веретено с рёбрами и меридианами ->
 * 8 огромных ног-арок (параметрические кривые) бьют в землю, оставляя трещины -> гребень из 7 шипов и хвост ->
 * красная буря, молнии между телом и лапами, пульсации по венам -> взрыв и рассыпание.
 */
public final class MindFlayerShow implements Show {
    private static final double PY = 75, RS = 19, HALF = 31, RB = 11;
    private static final int HEADS = 48, LEGS = 8, END = 900;
    private static final double[] LEG_L = {80, 92, 76, 96, 84, 94, 78, 88};
    private static final double[] LEG_Y0 = {66, 76, 62, 74, 68, 78, 61, 72};
    private static final double[] LEG_A = {16, 26, 21, 31, 18, 29, 24, 13};
    private static final int[] HEAD_COL = {0xFFE2A8, 0xFF8A3A, 0xFF3A22};

    private final Vec3d[] axis = new Vec3d[HEADS];
    private final Vec3d[] start = new Vec3d[HEADS];
    private final double[] omega = new double[HEADS];
    private final double[] legPhi = new double[LEGS];

    public MindFlayerShow() {
        Random r = new Random(7);
        double golden = Math.PI * (3 - Math.sqrt(5));
        for (int i = 0; i < HEADS; i++) {
            double y = 1 - 2.0 * (i + 0.5) / HEADS, rad = Math.sqrt(1 - y * y), th = i * golden;
            axis[i] = new Vec3d(Math.cos(th) * rad, y, Math.sin(th) * rad);
            start[i] = Fx.perp(axis[i]);
            omega[i] = (0.055 + 0.05 * r.nextDouble()) * (i % 2 == 0 ? 1 : -1);
        }
        for (int i = 0; i < LEGS; i++) legPhi[i] = i * Math.PI / 4 + 0.35;
    }

    @Override public String id() { return "mindflayer"; }
    @Override public String title() { return "Истязатель разума (большой): точка -> шар из полосок -> гигантский монстр"; }
    @Override public int duration() { return 960; }
    @Override public double distance() { return 140; }

    @Override
    public void tick(ShowContext c, int t) {
        if (t == 0) c.sound("minecraft:entity.warden.heartbeat", 1f, 0.6f);
        if (t == 40) c.sound("minecraft:block.beacon.activate", 1f, 0.5f);
        if (t == 320) c.sound("minecraft:entity.ender_dragon.growl", 1f, 0.5f);
        if (t == 840) c.sound("minecraft:entity.warden.sonic_boom", 1f, 0.6f);
        if (t > 0 && t % 36 == 0 && t < END) c.sound("minecraft:entity.warden.heartbeat", 0.8f, 0.6f);
        core(c, t);
        sphere(c, t);
        legs(c, t);
        body(c, t);
        extras(c, t);
        storm(c, t);
        finale(c, t);
    }

    private static int lo(double p0, double ds) { return (int) Math.floor(p0 / ds) + 1; }
    private static int hi(double p1, double ds) { return (int) Math.floor(p1 / ds); }

    // ---------- ядро ----------
    private void core(ShowContext c, int t) {
        if (t > END) return;
        double g = Fx.smooth(t / 40.0);
        double sz = (0.4 + 1.9 * g) * (1 + 0.25 * Math.sin(t * 0.22));
        Vec3d p = c.at(0, PY, 0);
        c.emit(new Spec(Kind.GLOW).pos(p).life(4).size(sz).color(0xFFF0DC).fade(1, 3));
        c.emit(new Spec(Kind.STAR).pos(p).life(4).size(sz * 2.0).color(0xFF5030).alpha(0.7).fade(1, 3));
        if (t >= 20 && t < 160 && t % 18 == 2)
            c.emit(new Spec(Kind.RING).pos(p).life(24).size(0.5).grow(1.0).color(0xFF6A3A).alpha(0.8).fade(2, 18));
        if (t >= 160 && t % 30 == 0 && t < END - 40)
            c.emit(new Spec(Kind.RING).pos(p).life(30).size(0.8).grow(1.7).color(0xFF3A22).alpha(0.7).fade(2, 22));
    }

    // ---------- шар из полосок ----------
    private double rs(int t) {
        if (t < 40 || t > 420) return 0;
        double up = Fx.smooth((t - 40) / 110.0);
        double down = 1 - 0.5 * Fx.smooth((t - 340) / 80.0);
        return RS * up * down;
    }

    private void sphere(ShowContext c, int t) {
        double R = rs(t);
        if (R <= 0) return;
        for (int i = 0; i < HEADS; i++) {
            for (int sub = 0; sub < 2; sub++) {
                Vec3d v = Fx.rot(start[i], axis[i], omega[i] * (t + sub * 0.5)).multiply(R);
                Vec3d w = c.at(v.x, PY + v.y, v.z);
                c.emit(new Spec(Kind.GLOW).pos(w).life(22).size(0.5).color(HEAD_COL[i % 3]).alpha(0.85).fade(1, 18));
                if (sub == 0) c.emit(new Spec(Kind.STAR).pos(w).life(2).size(1.0).color(0xFFFFFF).fade(0, 1));
            }
        }
    }

    // ---------- ноги ----------
    private Vec3d leg(int i, double s) {
        double d = 8 + (LEG_L[i] - 8) * Math.pow(s, 0.8);
        double y = LEG_Y0[i] + LEG_A[i] * Math.sin(Math.PI * Math.pow(s, 0.7)) - LEG_Y0[i] * s * s;
        return new Vec3d(Math.cos(legPhi[i]) * d, y, Math.sin(legPhi[i]) * d);
    }

    private static double legW(double s) { return 0.4 + 3.2 * Math.pow(1 - s, 1.15); }

    private void legs(ShowContext c, int t) {
        double ds = 1.0 / 170;
        for (int i = 0; i < LEGS; i++) {
            int t0 = 170 + i * 10;
            double p0 = Fx.ramp(t - 1, t0, t0 + 170), p1 = Fx.ramp(t, t0, t0 + 170);
            if (p1 > p0) {
                for (int q = lo(p0, ds); q <= hi(p1, ds); q++) {
                    double s = q * ds;
                    double w = legW(s);
                    int k = w > 2.3 ? 5 : (w > 1.5 ? 4 : (w > 0.8 ? 3 : 2));
                    tube(c, leg(i, s), leg(i, Math.min(1, s + 0.01)), w, k, Fx.mix(0xFF1E0E, 0xFFA060, s), t, 0.6);
                    if (q % 40 == 0) {
                        Vec3d j = leg(i, s);
                        c.emit(new Spec(Kind.STAR).pos(c.at(j.x, j.y, j.z)).life(END - t).size(1.3).color(0xFFB070).alpha(0.7).fade(4, 45).rise(0.004));
                    }
                }
                Vec3d h = leg(i, p1);
                c.emit(new Spec(Kind.GLOW).pos(c.at(h.x, h.y, h.z)).life(3).size(2.2).color(0xFFFFFF).fade(0, 2));
                c.emit(new Spec(Kind.STAR).pos(c.at(h.x, h.y, h.z)).life(3).size(3.6).color(0xFF6A3A).alpha(0.8).fade(0, 2));
            }
            if (p1 >= 1 && p0 < 1) impact(c, i, t);
            if (t > t0 + 170 && t < END - 40) {
                double s = ((t - t0) % 60) / 60.0;
                Vec3d q = leg(i, s);
                c.emit(new Spec(Kind.GLOW).pos(c.at(q.x, q.y, q.z)).life(3).size(1.2 + (1 - s) * 1.4).color(0xFFE0B0).alpha(0.9).fade(0, 2));
            }
        }
    }

    private void tube(ShowContext c, Vec3d a, Vec3d b, double w, int k, int col, int t, double size) {
        Random r = c.rng();
        Vec3d T = b.subtract(a);
        if (T.lengthSquared() < 1e-9) return;
        T = T.normalize();
        Vec3d n1 = Fx.perp(T), n2 = T.crossProduct(n1);
        double base = r.nextDouble() * Fx.TAU;
        for (int j = 0; j < k; j++) {
            double ang = base + j * Fx.TAU / k;
            Vec3d o = n1.multiply(Math.cos(ang) * w).add(n2.multiply(Math.sin(ang) * w));
            c.emit(new Spec(Kind.GLOW).pos(c.at(a.x + o.x, a.y + o.y, a.z + o.z)).life(Math.max(2, END - t)).size(size)
                    .color(col).alpha(0.8).fade(4, 45).rise(0.004));
        }
    }

    private void impact(ShowContext c, int i, int t) {
        Random r = c.rng();
        Vec3d e = leg(i, 1.0);
        Vec3d g = c.at(e.x, 0.4, e.z);
        Fx.shock(c, g, 1.2, 56, 0xFF5A2A, 28, 0.55);
        c.emit(new Spec(Kind.RING).pos(g).life(26).size(0.6).grow(0.9).color(0xFF4A2A).alpha(0.8).fade(1, 20));
        for (int k = 0; k < 36; k++)
            c.emit(new Spec(Kind.EMBER).pos(g).vel(r.nextGaussian() * 0.2, 0.3 + r.nextDouble() * 0.6, r.nextGaussian() * 0.2)
                    .gravity(0.03).life(34).size(0.4).color(0xFF9A40).fade(1, 16));
        // трещины на земле
        for (int k = 0; k < 5; k++) {
            double a = r.nextDouble() * Fx.TAU, x = e.x, z = e.z;
            for (int m = 0; m < 22; m++) {
                a += r.nextGaussian() * 0.25;
                x += Math.cos(a) * 0.7;
                z += Math.sin(a) * 0.7;
                c.emit(new Spec(Kind.GLOW).pos(c.at(x, 0.3, z)).life(Math.max(2, END - t)).size(0.4 * (1 - m / 28.0))
                        .color(0xFF3A1A).alpha(0.7).fade(4, 50));
            }
        }
        c.sound("minecraft:entity.generic.explode", 0.5f, 0.6f);
    }

    // ---------- тело ----------
    private void body(ShowContext c, int t) {
        if (t < 320 || t >= END) return;
        Random r = c.rng();
        int N = 64;
        double q0 = Fx.ramp(t - 1, 320, 470), q1 = Fx.ramp(t, 320, 470);
        int k0 = (int) Math.floor(q0 * N), k1 = Math.min(N, (int) Math.floor(q1 * N));
        for (int k = k0; k < k1; k++) {
            double u = (k + 0.5) / N;
            double y = PY + HALF * (1 - 2 * u);
            double rb = RB * Math.pow(Math.sin(Math.PI * u), 0.8) * (1 + 0.09 * Math.sin(u * 46));
            int n = Math.max(8, (int) (Fx.TAU * rb / 1.25));
            double off = r.nextDouble() * Fx.TAU;
            int col = Fx.mix(0xFF3A1E, 0xFFD090, 1 - Math.abs(2 * u - 1));
            for (int j = 0; j < n; j++) {
                double ang = off + j * Fx.TAU / n;
                c.emit(new Spec(Kind.GLOW).pos(c.at(Math.cos(ang) * rb, y, Math.sin(ang) * rb)).life(END - t).size(0.6)
                        .color(col).alpha(0.8).fade(4, 45).rise(0.004));
            }
            for (int m = 0; m < 8; m++) {
                double ang = m * Fx.TAU / 8 + u * 6;
                c.emit(new Spec(Kind.GLOW).pos(c.at(Math.cos(ang) * rb * 1.02, y, Math.sin(ang) * rb * 1.02)).life(END - t).size(0.85)
                        .color(0xFFC890).alpha(0.85).fade(4, 45).rise(0.004));
            }
            c.emit(new Spec(Kind.GLOW).pos(c.at(0, y, 0)).life(4).size(rb * 0.5 + 0.5).color(0xFFB080).alpha(0.5).fade(1, 3));
        }
    }

    // ---------- гребень и хвост ----------
    private Vec3d crown(int k, double s) {
        double az = k * Fx.TAU / 7, r = 2.5 + 11 * s;
        return new Vec3d(Math.cos(az) * r, PY + HALF - 4 + 19 * Math.pow(s, 0.8), Math.sin(az) * r);
    }

    private Vec3d tail(double s) { return new Vec3d(0, PY - HALF + 3 - 20 * s, 0); }

    private void extras(ShowContext c, int t) {
        Random r = c.rng();
        double ds = 1.0 / 46;
        if (t >= 470 && t < 540) {
            double p0 = Fx.ramp(t - 1, 470, 540), p1 = Fx.ramp(t, 470, 540);
            for (int q = lo(p0, ds); q <= hi(p1, ds); q++) {
                double s = q * ds;
                for (int k = 0; k < 7; k++)
                    tube(c, crown(k, s), crown(k, Math.min(1, s + 0.02)), 1.0 * (1 - s) + 0.15, 2, Fx.mix(0xFFA060, 0xFF2A18, s), t, 0.55);
                tube(c, tail(s), tail(Math.min(1, s + 0.02)), 1.8 * (1 - s) + 0.15, 3, Fx.mix(0xFF8A40, 0xFF2A18, s), t, 0.55);
            }
        }
        if (t >= 540 && t < 820 && t % 18 == 0) {
            double a = r.nextDouble() * Fx.TAU;
            Vec3d src = c.at(Math.cos(a) * 10, PY + (r.nextDouble() - 0.5) * 30, Math.sin(a) * 10);
            Vec3d tip = leg(r.nextInt(LEGS), 0.9 + 0.1 * r.nextDouble());
            Fx.bolt(c, src, c.at(tip.x, tip.y, tip.z), 0xFF7A50, 0.55, 7, 5);
        }
        if (t >= 500 && t < END - 60) {
            for (int i = 0; i < 24; i++) {
                int li = r.nextInt(LEGS);
                Vec3d q = leg(li, r.nextDouble());
                c.emit(new Spec(Kind.SPARK).pos(c.at(q.x, q.y, q.z)).vel(r.nextGaussian() * 0.03, 0.04, r.nextGaussian() * 0.03)
                        .life(10).size(0.6).color(0xFFE0B0).fade(1, 6).twinkle());
            }
        }
    }

    // ---------- красная буря ----------
    private void storm(ShowContext c, int t) {
        if (t < 220 || t > END) return;
        Random r = c.rng();
        double env = Fx.ramp(t, 220, 320) * (1 - Fx.ramp(t, END - 60, END));
        int n = (int) (14 * env);
        for (int i = 0; i < n; i++) {
            double ang = r.nextDouble() * Fx.TAU, rad = 20 + r.nextDouble() * 100, y = 118 + r.nextDouble() * 18;
            c.emit(new Spec(Kind.GLOW).pos(c.at(Math.cos(ang) * rad, y, Math.sin(ang) * rad))
                    .vel(-Math.sin(ang) * 0.2, 0, Math.cos(ang) * 0.2).life(50).size(6 + 4 * r.nextDouble())
                    .color(Fx.mix(0x7A0C10, 0xC02A18, r.nextDouble())).alpha(0.16).fade(15, 25));
        }
        if (t > 280 && t < END - 30 && r.nextInt(20) == 0) {
            double ang = r.nextDouble() * Fx.TAU, rad = 25 + r.nextDouble() * 70;
            Fx.bolt(c, c.at(Math.cos(ang) * rad * 0.6, 125, Math.sin(ang) * rad * 0.6),
                    c.at(Math.cos(ang) * rad, 0.5, Math.sin(ang) * rad), 0xFF6A50, 0.6, 7, 7);
            c.sound("minecraft:entity.lightning_bolt.thunder", 0.6f, 0.7f);
        }
    }

    // ---------- финал ----------
    private void finale(ShowContext c, int t) {
        if (t != 840) return;
        Random r = c.rng();
        Vec3d p = c.at(0, PY, 0);
        c.emit(new Spec(Kind.GLOW).pos(p).life(14).size(20).color(0xFFFFFF).alpha(0.9).fade(1, 12));
        for (int k = 0; k < 280; k++) {
            double a = k * Fx.TAU / 280;
            c.emit(new Spec(Kind.GLOW).pos(p).vel(Math.cos(a) * 2.8, r.nextGaussian() * 0.05, Math.sin(a) * 2.8)
                    .life(32).size(0.9).color(0xFF6A3A).drag(0.97).fade(1, 20));
        }
        Fx.shock(c, c.at(0, 0.4, 0), 2.6, 240, 0xFF4020, 36, 0.75);
    }
}
