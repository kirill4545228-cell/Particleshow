package com.particleshow.show;

import net.minecraft.util.math.Vec3d;
import java.util.Random;

/** Всё, что нужно шоу для рисования. Реализация живёт на клиенте. */
public interface ShowContext {
    Vec3d center();
    double scale();
    Random rng();
    /** Горизонтальный единичный вектор от центра шоу к зрителю. */
    Vec3d toViewer();
    void emit(Spec s);
    /** vol 0..1 (звук слышен везде, не позиционный). */
    void sound(String id, float vol, float pitch);
    /** Строка рассказчика над хотбаром (необязательно). */
    default void say(String text) {}

    /** Локальные координаты (блоки при масштабе 1) -> мировые. */
    default Vec3d at(double x, double y, double z) {
        return center().add(x * scale(), y * scale(), z * scale());
    }
}
