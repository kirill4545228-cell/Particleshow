package com.particleshow.show;

import net.minecraft.util.math.Vec3d;
import java.util.Random;

/** Разрыв в Изнанку: трещины -> огненное кольцо портала -> вихрь внутри -> щупальца тянутся к зрителю, парят споры, бьют молнии. */
public final class RiftShow implements Show {
    private static final double PY = 36, R = 26;
    private static final int END = 720, TEND = 8;

    @Override public String id() { return "rift"; }
    @Override public String title() { return "Разрыв в Изнанку: портал, щупальца, споры и молнии"; }
    @Override public int duration() { return 780; }
    @Override public double distance() { return 70; }

    private Vec3d P(ShowContext c, Vec3d rt, Vec3d n, double u, double w, double d) {
        return c.at(rt.x * u + n.x * d, PY + w, rt.z * u + n.z * d);
    }

    @Override
    public void tick(ShowContext c, int t) {
        Random r = c.rng();
        if (t == 0) c.sound("minecraft:block.portal.ambient", 1f, 0.6f);
        if (t == 100) c.sound("minecraft:block.end_portal.spawn", 0.8f, 0.5f);
        if (t == 700) c.sound("minecraft:entity.warden.sonic_boom", 1f, 0.7f);
        Vec3d n = c.toViewer();
        Vec3d rt = new Vec3d(-n.z, 0, n.x);

        if (t < 100 && t % 5 == 0) {
            double a = r.nextDouble() * Fx.TAU, len = 10 + r.nextDouble() * 22;
            Fx.bolt(c, P(c, rt, n, 0, 0, 0), P(c, rt, n, Math.cos(a) * len, Math.sin(a) * len, r.nextGaussian() * 2), 0xFF5A40, 0.5, 8, 2);
        }
        double Rr = R * Fx.smooth((t - 40) / 120.0) * (1 - Fx.ramp(t, 700, 770));
        if (Rr > 0.5) {
            for (int i = 0; i < 180; i++) {
                double a = r.nextDouble() * Fx.TAU, rad = Rr + r.nextGaussian() * 0.7;
                int col = Fx.mix(0xFF2A2A, 0xFFB070, 0.5 + 0.5 * Math.sin(a * 5 - t * 0.15));
                c.emit(new Spec(Kind.GLOW).pos(P(c, rt, n, Math.cos(a) * rad, Math.sin(a) * rad, r.nextGaussian() * 0.5))
                        .life(3).size(0.55).color(col).alpha(0.85).fade(1, 2));
            }
            for (int i = 0; i < 30; i++) {
                double a = r.nextDouble() * Fx.TAU;
                Vec3d dir = new Vec3d(rt.x * Math.cos(a) * 0.08, Math.sin(a) * 0.08, rt.z * Math.cos(a) * 0.08);
                c.emit(new Spec(Kind.EMBER).pos(P(c, rt, n, Math.cos(a) * Rr, Math.sin(a) * Rr, 0)).vel(dir).life(20).size(0.4)
                        .color(0xFF7A30).fade(1, 12));
            }
            if (t > 60) {
                for (int i = 0; i < 220; i++) {
                    double rho = Rr * Math.sqrt(r.nextDouble());
                    double th = r.nextInt(4) * Math.PI / 2 + 3.8 * Math.pow(rho / R, 0.7) + t * 0.07 * (1 - rho / R * 0.4);
                    c.emit(new Spec(Kind.GLOW).pos(P(c, rt, n, Math.cos(th) * rho, Math.sin(th) * rho, r.nextGaussian() * 0.3))
                            .life(3).size(0.9).color(Fx.mix(0x8A1FFF, 0xFF2A50, r.nextDouble())).alpha(0.45).fade(1, 2));
                }
                Vec3d cc = P(c, rt, n, 0, 0, 0);
                c.emit(new Spec(Kind.GLOW).pos(cc).life(3).size(4 + Math.sin(t * 0.2)).color(0xFFD0C0).alpha(0.8).fade(1, 2));
                c.emit(new Spec(Kind.STAR).pos(cc).life(3).size(7).color(0xFF3A30).alpha(0.6).fade(1, 2));
            }
            if (t >= 100 && t % 10 == 0) {
                double a = r.nextDouble() * Fx.TAU, a2 = r.nextDouble() * Fx.TAU;
                Fx.bolt(c, P(c, rt, n, Math.cos(a) * Rr, Math.sin(a) * Rr, 0),
                        P(c, rt, n, Math.cos(a2) * Rr * 2, Math.sin(a2) * Rr * 2, (r.nextDouble() - 0.3) * 30), 0xFF8A60, 0.5, 7, 4);
            }
            if (t >= 160 && t % 40 == 0)
                c.emit(new Spec(Kind.RING).pos(P(c, rt, n, 0, 0, 0)).life(30).size(1).grow(0.9).color(0xFF3A3A).alpha(0.7).fade(2, 22));
        }
        // щупальца
        if (t >= 140 && t < END) {
            for (int j = 0; j < 8; j++) {
                int t0 = 140 + j * 6;
                double p0 = Fx.ramp(t - 1, t0, t0 + 200), p1 = Fx.ramp(t, t0, t0 + 200);
                for (double s = p0; s < p1; s += 1.0 / 230) {
                    double aj = j * Fx.TAU / 8;
                    double rr = 4 + 55 * s, th = aj + 1.8 * s + 0.5 * Math.sin(s * 9 + j), d = 50 * Math.pow(s, 1.2);
                    double w = 0.35 * (1 - s) + 0.1, ph = r.nextDouble() * Fx.TAU;
                    for (int k = 0; k < 2; k++) {
                        double ang = ph + k * Fx.TAU / 2;
                        c.emit(new Spec(Kind.GLOW).pos(P(c, rt, n, Math.cos(th) * rr + Math.cos(ang) * w, Math.max(1 - PY, Math.sin(th) * rr + Math.sin(ang) * w), d))
                                .life(Math.max(2, END - t + TEND)).size(0.5).color(Fx.mix(0xB0102A, 0xFF6A50, s)).alpha(0.8).fade(4, 40).rise(0.003));
                    }
                }
            }
        }
        // споры
        if (t >= 30 && t < END) {
            for (int i = 0; i < 14; i++) {
                Vec3d d = Fx.randDir(r).multiply(70 * Math.cbrt(r.nextDouble()));
                c.emit(new Spec(Kind.STAR).pos(c.at(d.x, PY + d.y, d.z)).vel(r.nextGaussian() * 0.01, 0.03 + r.nextDouble() * 0.03, r.nextGaussian() * 0.01)
                        .life(110).size(0.22).color(0xFFF0D8).alpha(0.8).fade(15, 30).twinkle());
            }
        }
        if (t == 700) {
            Vec3d cc = P(c, rt, n, 0, 0, 0);
            c.emit(new Spec(Kind.GLOW).pos(cc).life(14).size(20).color(0xFFFFFF).alpha(0.9).fade(1, 12));
            for (int i = 0; i < 300; i++) {
                double a = i * Fx.TAU / 300;
                c.emit(new Spec(Kind.GLOW).pos(cc).vel(rt.x * Math.cos(a) * 2.2, Math.sin(a) * 2.2, rt.z * Math.cos(a) * 2.2)
                        .drag(0.96).life(40).size(0.7).color(0xFF4A3A).fade(1, 25));
            }
        }
    }
}
